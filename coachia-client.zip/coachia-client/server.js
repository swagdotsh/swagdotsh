import http from 'node:http';
import { readFile } from 'node:fs/promises';

const port = Number(process.env.PORT || 3000);
const base = process.env.LM_STUDIO_URL || 'http://127.0.0.1:1234';
const headers = { 'Content-Type': 'application/json' };
if (process.env.LM_STUDIO_API_KEY) headers.Authorization = `Bearer ${process.env.LM_STUDIO_API_KEY}`;

async function studio(path, options = {}) {
  const response = await fetch(`${base}${path}`, {
    ...options, headers, signal: AbortSignal.timeout(180000),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `LM Studio returned ${response.status}.`);
  return data;
}

const server = http.createServer(async (req, res) => {
  const json = (status, data) => {
    res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(data));
  };
  try {
    if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
      const page = await readFile(new URL('./index.html', import.meta.url));
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(page);
    }
    if (req.method !== 'POST' || req.url !== '/api/chat') return json(404, { error: 'Not found.' });
    if (req.headers.origin && req.headers.origin !== `http://${req.headers.host}`) {
      return json(403, { error: 'Invalid request origin.' });
    }
    let body = '';
    for await (const chunk of req) {
      body += chunk;
      if (Buffer.byteLength(body) > 1024 * 1024) return json(413, { error: 'Conversation is too long. Start a new chat.' });
    }
    let messages;
    try { ({ messages } = JSON.parse(body)); }
    catch { return json(400, { error: 'Invalid JSON.' }); }
    if (!Array.isArray(messages) || !messages.length || messages.some(m =>
      !m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string' || !m.content.trim()
    ) || messages.at(-1).role !== 'user') return json(400, { error: 'Invalid messages.' });
    const model = process.env.LM_STUDIO_MODEL || (await studio('/v1/models')).data?.[0]?.id;
    if (!model) throw new Error('No model available. Load a model in LM Studio and try again.');
    const data = await studio('/v1/chat/completions', {
      method: 'POST',
      body: JSON.stringify({ model, messages: messages.map(({ role, content }) => ({ role, content })), stream: false }),
    });
    const reply = data.choices?.[0]?.message?.content;
    if (typeof reply !== 'string' || !reply.trim()) throw new Error('The model returned an empty reply. Please try again.');
    json(200, { reply });
  } catch (error) {
    const message = error.name === 'TimeoutError'
      ? 'LM Studio took too long to reply. Please try again.'
      : error.message === 'fetch failed'
        ? 'Cannot connect to LM Studio. Start its local server on port 1234 and load a model.'
        : error.message;
    json(502, { error: message });
  }
});
server.listen(port, '127.0.0.1', () => console.log(`coachia v1 is running at http://localhost:${port}`));
