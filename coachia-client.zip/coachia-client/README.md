# coachia v1

A minimal local chat page with a Node.js proxy to LM Studio. No packages to install.

1. Use Node.js 22 or later.
2. Load a chat model in LM Studio and start its local server on port 1234.
3. Run `npm start` in this project.
4. Open http://localhost:3000 (use the Node server, not an HTML file preview).

Messages stay in page memory. New chat or reloading clears the conversation. Each request includes the conversation so the model can follow along.

Optional environment variables: `PORT` (default 3000), `LM_STUDIO_URL` (default http://127.0.0.1:1234), `LM_STUDIO_MODEL` (otherwise first model returned by LM Studio), and `LM_STUDIO_API_KEY` if you enabled authentication.

API reference: https://lmstudio.ai/docs/developer/openai-compat
